import { useState } from "react";
import { EventDef } from "../types";

/* ─── helpers ───────────────────────────────────────────────────────── */

function parseBold(text: string): React.ReactNode {
  return text.split(/\*\*(.*?)\*\*/g).map((part, i) =>
    i % 2 === 1
      ? <strong key={i} style={{ color: "inherit", fontWeight: 700 }}>{part}</strong>
      : part
  );
}

const TRACK_META: Record<string, { label: string; color: string }> = {
  single:    { label: "Fase 1 · Trilho Único",  color: "#3b82f6" },
  anterior:  { label: "Intestino Anterior",      color: "#3b82f6" },
  medio:     { label: "Intestino Médio",         color: "#06b6d4" },
  posterior: { label: "Intestino Posterior",     color: "#818cf8" },
};

function Pill({ text, color }: { text: string; color: string }) {
  return (
    <span style={{
      padding: "2px 9px", borderRadius: 6,
      border: `1px solid ${color}44`,
      background: `${color}16`, color,
      fontSize: 9, fontWeight: 700, letterSpacing: 0.5, whiteSpace: "nowrap",
    }}>
      {text}
    </span>
  );
}

/* ─── component ──────────────────────────────────────────────────────── */

interface Props {
  event: EventDef;
  onClose: () => void;
  onAnswered: (id: string) => void;
  preAnswered: boolean;
}

export function EventDetailModal({ event, onClose, onAnswered, preAnswered }: Props) {
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(preAnswered);

  const track = TRACK_META[event.track] ?? TRACK_META.single;
  const color = track.color;

  const choose = (i: number) => {
    if (answered) return;
    setSelected(i);
    setAnswered(true);
    onAnswered(event.id);
  };

  const optStyle = (i: number): React.CSSProperties => {
    const base: React.CSSProperties = {
      width: "100%", textAlign: "left", padding: "9px 13px",
      borderRadius: 9, border: "1px solid", fontSize: 11.5, lineHeight: 1.45,
      cursor: "pointer", transition: "all 0.15s", background: "transparent",
      fontFamily: "inherit", display: "flex", alignItems: "flex-start", gap: 9,
    };
    if (!answered)
      return { ...base, borderColor: `${color}40`, color: "#94a3b8" };
    if (i === event.correctIndex)
      return { ...base, borderColor: "#22c55e77", background: "#052e1688", color: "#4ade80", cursor: "default" };
    if (i === selected)
      return { ...base, borderColor: "#ef444477", background: "#2d060688", color: "#f87171", cursor: "default" };
    return { ...base, borderColor: "rgba(255,255,255,0.05)", color: "#374151", cursor: "default" };
  };

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: "fixed", inset: 0,
          background: "rgba(0,0,0,0.72)",
          backdropFilter: "blur(5px)",
          zIndex: 100,
        }}
      />

      {/* Modal card */}
      <div style={{
        position: "fixed",
        top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
        width: "min(660px, 93vw)",
        maxHeight: "88vh",
        background: "#09111f",
        border: `1px solid ${color}33`,
        borderRadius: 18,
        boxShadow: `0 0 0 1px rgba(255,255,255,0.04), 0 28px 70px rgba(0,0,0,0.7), 0 0 50px ${color}14`,
        zIndex: 101,
        display: "flex", flexDirection: "column",
        overflow: "hidden",
      }}>

        {/* Top accent stripe */}
        <div style={{
          height: 3, flexShrink: 0,
          background: `linear-gradient(90deg, ${color}00, ${color}dd, ${color}00)`,
        }} />

        {/* Header */}
        <div style={{
          padding: "16px 20px 14px", flexShrink: 0,
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          display: "flex", alignItems: "flex-start", gap: 10,
        }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
              <Pill text={event.code}  color={color} />
              <Pill text={track.label} color={color} />
              <Pill text={event.period} color="#64748b" />
            </div>
            <h2 style={{
              margin: 0, fontSize: 18, fontWeight: 800,
              color: "#f1f5f9", letterSpacing: -0.5, lineHeight: 1.3,
            }}>
              {event.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            style={{
              flexShrink: 0, width: 30, height: 30, borderRadius: 8,
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#64748b", fontSize: 18, cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "inherit", lineHeight: 1,
            }}
          >×</button>
        </div>

        {/* Scrollable body */}
        <div style={{
          flex: 1, overflowY: "auto",
          padding: "18px 20px 22px",
          scrollbarWidth: "thin",
          scrollbarColor: "#1e293b #09111f",
        }}>

          {/* Evento principal */}
          <div style={{
            padding: "11px 14px", borderRadius: 10,
            background: `${color}0c`, border: `1px solid ${color}22`,
            marginBottom: 18,
          }}>
            <div style={{
              fontSize: 8.5, color: color, fontWeight: 700,
              letterSpacing: 1.8, textTransform: "uppercase", marginBottom: 5,
            }}>
              Evento principal
            </div>
            <p style={{ margin: 0, fontSize: 12.5, color: "#cbd5e1", lineHeight: 1.6 }}>
              {event.mainEvent}
            </p>
          </div>

          {/* Desenvolvimento */}
          <SectionLabel>Desenvolvimento</SectionLabel>
          <ul style={{ margin: "10px 0 20px", padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
            {event.development.map((bullet, i) => (
              <li key={i} style={{
                display: "flex", gap: 10, alignItems: "flex-start",
                fontSize: 12, color: "#94a3b8", lineHeight: 1.65,
              }}>
                <span style={{
                  flexShrink: 0, marginTop: 7,
                  width: 5, height: 5, borderRadius: "50%",
                  background: color, opacity: 0.7,
                  display: "block",
                }} />
                <span>{parseBold(bullet)}</span>
              </li>
            ))}
          </ul>

          {/* Divider */}
          <div style={{ height: 1, background: "rgba(255,255,255,0.06)", marginBottom: 18 }} />

          {/* Questão */}
          <SectionLabel>Questão</SectionLabel>
          <p style={{ fontSize: 12.5, color: "#cbd5e1", lineHeight: 1.6, margin: "10px 0 14px" }}>
            {event.question}
          </p>

          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {event.options.map((opt, i) => (
              <button key={opt.letter} style={optStyle(i)} onClick={() => choose(i)}>
                <span style={{ fontWeight: 800, color: color, flexShrink: 0, fontSize: 10.5 }}>
                  {opt.letter})
                </span>
                <span>{opt.text}</span>
              </button>
            ))}
          </div>

          {answered && (
            <div style={{
              marginTop: 14, padding: "12px 14px", borderRadius: 10,
              background: "rgba(34,197,94,0.07)",
              border: "1px solid rgba(34,197,94,0.22)",
            }}>
              <div style={{
                fontSize: 8.5, color: "#4ade80", fontWeight: 700,
                letterSpacing: 1.8, textTransform: "uppercase", marginBottom: 6,
              }}>
                Explicação
              </div>
              <p style={{ margin: 0, fontSize: 12, color: "#86efac", lineHeight: 1.6 }}>
                {event.explanation}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ─── section label ──────────────────────────────────────────────────── */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 8.5, color: "#64748b", fontWeight: 700,
      letterSpacing: 1.8, textTransform: "uppercase",
    }}>
      {children}
    </div>
  );
}
